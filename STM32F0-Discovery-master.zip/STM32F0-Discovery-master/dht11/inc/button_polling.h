#ifndef __BUTTON_POLLING_H__
#define __BUTTON_POLLING_H__

#include "project.h"

extern int check_button_polling(unsigned int pin, PORT port);

#endif
